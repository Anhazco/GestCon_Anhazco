package py.edu.gestcon.interfaces;

public interface InterfaceAcciones {
	public void nuevo();
	public void modificar();
	public void eliminar();
	public void salir();
	public void cancelar();
	public void guardar();
	public void actualizar();
}
