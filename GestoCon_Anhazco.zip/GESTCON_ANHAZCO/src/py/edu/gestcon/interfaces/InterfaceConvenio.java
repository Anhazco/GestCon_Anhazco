package py.edu.gestcon.interfaces;

import py.edu.gestcon.entidades.Convenio;

public interface InterfaceConvenio {
	public void seleccionarConvenio(Convenio convenio);
}
