package py.edu.gestcon.interfaces;

import py.edu.gestcon.entidades.Institucion;

public interface InterfaceInstitucion {
	
	public void seleccionarInstitucion(Institucion institucion);
}
