package py.edu.gestcon.interfaces;

import py.edu.gestcon.entidades.Universidad;

public interface InterfaceUniversidad {

	public void seleccionarUniversidad(Universidad universidad);
}


