package py.edu.gestcon.interfaces;

import py.edu.gestcon.entidades.Unidad_academica;

public interface InterfaceUnidadAcademica {
	public void seleccionarUnidadAcademica(Unidad_academica unidad_academica);
}
