package py.edu.gestcon.interfaces;

import py.edu.gestcon.entidades.Firmantes;

public interface InterfaceFirmante {
	public void seleccionarFirmante(Firmantes firmantes);
}
