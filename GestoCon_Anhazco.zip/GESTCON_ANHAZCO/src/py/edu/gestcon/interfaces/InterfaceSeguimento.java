package py.edu.gestcon.interfaces;

import py.edu.gestcon.entidades.Seguimiento;
public interface InterfaceSeguimento {
	public void seleccionarSeguimiento(Seguimiento seguimiento);

}
